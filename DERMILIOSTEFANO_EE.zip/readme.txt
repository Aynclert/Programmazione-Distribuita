Cognome e nome: D'Ermilio Stefano

Breve descrizione riassuntiva delle modifiche:
aggiunta di un nuovo webservice ejb creato da zero, invece che dall'ejb esistente, modifica di alcuni errori di distrazione, aggiunta di un try-catch

-------------------------------------------------------------------------------------------------------------------

PROGETTO: DERMILIOSTEFANO_EJB_JMS_WS


FILE: Consegna.java

Linea 15: aggiunta dell'annotazione @XmlRootElement

Linea 78: implementazione della logica di business per il calcolo dei giorni dall'ordine



FILE: EJB.java

Linea 7: tolta l'annotazione @WebService in favore della creazione di un WebService nuovo

Linea 20: modificato il modo di rimuovere un oggetto gestito, da em.remove(c) a em.persist(em.merge(c))

Linea 24: modificato il tipo di ritorno del metodo, da void a Consegna

Linea 33: modificato il metodo da .getResult() a .getResultList()

Linea 39: modifica dell'ultima restituzione, da c.getDataOrdine a c.getStato(), ed aggiunta delle parentesi a c.getDescrizione



FILE: DBProducer.java

Linea 10: modifica da PersistentContext a PersistenceContext



FILE: DBSingleton.java

Linea 15: specificazione del package di appartenenza per evitare ambiguità



FILE: MDB.java

Linea 18: inserimento dell'intero blocco di istruzioni successivo in un blocco try-catch per recuperare eventuali JMSException

Linea 22: separati i controlli relativi allo stato di c



FILE: WSEJB.java (creato da 0 come WebServiceEJB)

Linea 7: definito il nome del Web Service

Linea 10: iniezione dell'ejb creato in precedenza

Linea 12: aggiunta dell'annotazione @Webmethod al metodo, il quale è stato copiato da EJB.java

-------------------------------------------------------------------------------------------------------------------

PROGETTO: DERMILIOSTEFANO_Consegne


FILE: Client.java

Linea 11: modifica da "implements" a "throws" per la NamingException



FILE: MDBClient.java

Linea 10: modifica da "implements" a "throws" per la NamingException

Linea 22: eliminazione del segmento "catch(){...}

-------------------------------------------------------------------------------------------------------------------